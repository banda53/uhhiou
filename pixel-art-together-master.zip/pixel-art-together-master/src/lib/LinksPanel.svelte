<script>
  import poweredByLiveblocks from "../../static/poweredbyliveblocks.svg";
</script>

<div class="mx-5 mb-16 flex w-full pb-1 md:mb-0 md:pb-0 xl:mt-5 xl:justify-end">
  <a
    class="focus-visible-style group relative overflow-hidden rounded-[7px] ring-1 ring-inset ring-transparent transition-all hover:ring-[color:var(--sl-color-primary-200)] "
    href="https://liveblocks.io"
    target="_blank"
  >
    <img alt="Powered by Liveblocks.io" src={poweredByLiveblocks} />
    <div
      class="absolute inset-0 bg-[color:var(--sl-color-primary-100)] opacity-0 mix-blend-darken transition-opacity group-hover:opacity-20"
    ></div>
  </a>
</div>
