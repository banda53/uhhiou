// Symbols are used for context to avoid polluting the global scope
export const clientSymbol = Symbol();
export const roomSymbol = Symbol();
